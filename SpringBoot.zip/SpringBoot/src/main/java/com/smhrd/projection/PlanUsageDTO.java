// com.smhrd.dto.PlanUsageDTO.java
package com.smhrd.projection;

public class PlanUsageDTO {
    private String planType; // 탐구형 / 필수형
    private long userCount;
    private double rate; // 비율
    private double refundRate; // 환급률

    public PlanUsageDTO(String planType, long userCount, double rate, double refundRate) {
        this.planType = planType;
        this.userCount = userCount;
        this.rate = rate;
        this.refundRate = refundRate;
    }

    public String getPlanType() {
        return planType;
    }

    public long getUserCount() {
        return userCount;
    }

    public double getRate() {
        return rate;
    }

    public double getRefundRate() {
        return refundRate;
    }
}
