package com.smhrd.projection;

public interface LiIdxAndLiName {
	int getLiIdx();
	String getLiName();
}
