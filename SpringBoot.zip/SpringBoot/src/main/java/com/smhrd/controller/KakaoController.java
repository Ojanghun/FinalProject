package com.smhrd.controller;


import java.util.HashMap;
import java.util.Map;

import com.smhrd.entity.Member;
import com.smhrd.service.MemberService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.client.RestTemplate;

@Controller
public class KakaoController {

    @Value("${kakao.client-id}")
    private String clientId;

    @Value("${kakao.redirect-uri}")
    private String redirectUri;

    private final MemberService service;

    public KakaoController(MemberService service) {
        this.service = service;
    }

    @GetMapping("/oauth/kakao")
    public String kakaoLogin(String code, HttpSession session, RedirectAttributes redirect) throws Exception {
        // 1. 액세스 토큰 요청 & 사용자 정보 요청 (생략)
        // ...

        // 2. 닉네임 추출
        String nickname = kakaoProfile.get("properties").get("nickname").asText();

        // 3. 세션이나 Redirect로 넘기기
        session.setAttribute("kakaoNick", nickname); // 또는
        // redirect.addAttribute("nick", nickname);  // URL 파라미터 방식도 가능

        return "redirect:/join";  // 회원가입 폼 페이지로 이동
    }
    }


