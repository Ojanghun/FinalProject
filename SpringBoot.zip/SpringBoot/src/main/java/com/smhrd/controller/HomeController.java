package com.smhrd.controller;

public class HomeController {

}
